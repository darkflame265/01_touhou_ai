# env/obs_builder.py
import cv2
import numpy as np
from env.template_tracker import MultiTemplateTracker

class ObsBuilder:
    def __init__(self, screen, debug_viz=None, obs_out_size=84, crop_size=160, use_fallback_full_preprocess=True):
        self.screen = screen
        self.debug = debug_viz

        self.obs_out_size = obs_out_size
        self.crop_size = crop_size
        self.use_fallback_full_preprocess = use_fallback_full_preprocess

        img0 = self.screen.capture()
        h0, w0 = img0.shape[:2]
        self.H, self.W = h0, w0
        self.tracker = MultiTemplateTracker(
            frame_w=w0,
            frame_h=h0,
            template_paths=[
                "assets/reimu_still.png",
                "assets/reimu_left.png",
                "assets/reimu_right.png",
                "assets/reimu_still_tight.png",
                "assets/reimu_left_tight.png",
                "assets/reimu_right_tight.png",
            ],
            init_xy=(w0 // 2, int(h0 * 0.78)),
            ema_alpha=0.35,
            base_search_radius=260,
            scales=(0.97, 1.0, 1.03),
            min_score=0.40,
            min_margin=0.08,
            red_min_ratio=0.06,
            white_min_ratio=0.09,
        )


        self.player_center = None  # (x,y)

        # =========================
        # ✅ UI 영역 제외 설정
        # =========================
        # 우측 UI를 통째로 제외: 화면 가로의 몇 %를 UI로 볼지
        # 보통 0.72~0.82 사이가 맞음. (너 화면에 맞게 숫자만 조절)
        self.ui_cut_ratio = 0.66

        # UI 내부에서도 아래쪽 "홍마향" 텍스트가 문제면 아래쪽만 더 강하게 제외 가능
        # (ui_cut_ratio로 우측을 다 자르면 보통 필요 없음)
        self.ui_cut_bottom_ratio = 1.00  # 1.0이면 하단 추가 컷 없음

    def _crop_square_bgr(self, img_bgr, cx, cy, size):
        h, w = img_bgr.shape[:2]
        half = size // 2
        x1 = int(round(cx - half)); y1 = int(round(cy - half))
        x2 = x1 + size;          y2 = y1 + size

        pad_l = max(0, -x1); pad_t = max(0, -y1)
        pad_r = max(0, x2 - w); pad_b = max(0, y2 - h)

        if pad_l or pad_t or pad_r or pad_b:
            img_bgr = cv2.copyMakeBorder(img_bgr, pad_t, pad_b, pad_l, pad_r,
                                         borderType=cv2.BORDER_CONSTANT, value=(0,0,0))
            x1 += pad_l; y1 += pad_t
            x2 += pad_l; y2 += pad_t

        return img_bgr[y1:y2, x1:x2]

    def _mask_out_ui_region(self, img_bgr: np.ndarray) -> np.ndarray:
        """
        트래커 입력에서 우측 UI 영역을 "검정"으로 지워버림.
        (주의) crop 관측은 원본 img_bgr에서 하고, 트래커만 이걸로 돌림.
        """
        out = img_bgr.copy()

        x_ui = int(self.W * self.ui_cut_ratio)
        # 우측 UI 제거
        out[:, x_ui:, :] = 0

        # 필요 시 우측 UI 하단만 추가로 제거(옵션)
        if self.ui_cut_bottom_ratio < 1.0:
            y0 = int(self.H * self.ui_cut_bottom_ratio)
            out[y0:, x_ui:, :] = 0

        return out

    def make_state(self, img_bgr):
        # ✅ 트래커 입력만 UI 제거한 프레임 사용
        img_for_track = self._mask_out_ui_region(img_bgr)
        tr = self.tracker.update(img_for_track)

        # ✅ cand(템플릿이 찾은 위치)가 있으면 cand를 우선 사용
        cand = getattr(self.tracker, "dbg_candidate_center", None)
        votes = getattr(self.tracker, "dbg_votes", 0)

        # ✅ 합의가 충분할 때만 cand 사용
        if (cand is not None) and (int(votes) >= 2):
            cx, cy = int(cand[0]), int(cand[1])
        else:
            cx, cy = int(tr.x), int(tr.y)


        self.player_center = (cx, cy)

        # 디버그도 "트래커가 실제로 본 화면" 기준으로 보여주면 원인 확인이 더 쉬움
        if self.debug is not None:
            self.debug.show_tracker(img_for_track, self.tracker, tr, self.crop_size)

        # ✅ cand가 없거나(conf가 너무 낮거나) 완전 붕괴한 경우에만 fallback
        cand = getattr(self.tracker, "dbg_candidate_center", None)
        if self.use_fallback_full_preprocess:
            if (cand is None) or (tr.conf <= 0.01):
                return self.screen.preprocess(img_bgr)


        # ✅ crop은 원본에서 (UI 제거하면 색/밝기 정보가 깨질 수 있으니 원본 유지)
        crop_bgr = self._crop_square_bgr(img_bgr, cx, cy, self.crop_size)
        crop_gray = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2GRAY)
        obs = cv2.resize(crop_gray, (self.obs_out_size, self.obs_out_size), interpolation=cv2.INTER_AREA)
        return obs.astype(np.float32) / 255.0
