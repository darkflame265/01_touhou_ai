from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import cv2
from typing import List, Tuple


@dataclass
class TrackResult:
    x: int
    y: int
    conf: float
    found: bool
    method: str  # "tmpl"


class MultiTemplateTracker:
    """
    Multi-template edge-based tracker.

    추가한 것(A):
    - 템플릿/스케일별 후보(best)들을 모아서
    - 서로 가까운 후보가 2개 이상이면(합의) 그 위치를 채택
    - 합의 실패하면 vote reject로 처리 (오탐 점프 감소)
    """

    def __init__(
        self,
        frame_w: int,
        frame_h: int,
        template_paths: List[str],
        init_xy: tuple[int, int] | None = None,

        ema_alpha: float = 0.35,
        base_search_radius: int = 260,
        scales: tuple[float, ...] = (0.95, 0.97, 1.0, 1.03, 1.05),

        # ===== 점수 기준 =====
        min_score: float = 0.42,
        min_margin: float = 0.08,

        method: int = cv2.TM_CCOEFF_NORMED,

        # ===== 색 게이트 =====
        red_min_ratio: float = 0.06,
        white_min_ratio: float = 0.09,

        # ===== 소프트 트래킹 =====
        soft_update_score: float = 0.25,
        soft_alpha: float = 0.12,

        # ===== 재획득 / 안정화 =====
        strong_score: float = 0.55,
        max_jump: int = 90,

        # ===== NEW: 합의(vote) 파라미터 =====
        vote_radius: int = 18,     # 후보들끼리 "같은 위치"로 볼 거리(px)
        vote_min: int = 2,         # 최소 몇 개 후보가 모여야 채택할지
        vote_min_score: float = 0.30,  # 후보 리스트에 포함시킬 최소 score (너무 약한 후보 제외)
    ):
        self.w = frame_w
        self.h = frame_h

        self.ema_alpha = float(ema_alpha)
        self.base_r = int(base_search_radius)
        self.scales = tuple(scales)

        self.min_score = float(min_score)
        self.min_margin = float(min_margin)

        self.method = method
        self.red_min_ratio = float(red_min_ratio)
        self.white_min_ratio = float(white_min_ratio)

        self.soft_update_score = float(soft_update_score)
        self.soft_alpha = float(soft_alpha)

        self.strong_score = float(strong_score)
        self.max_jump = int(max_jump)

        # NEW
        self.vote_radius = int(vote_radius)
        self.vote_min = int(vote_min)
        self.vote_min_score = float(vote_min_score)

        if not template_paths:
            raise ValueError("template_paths must be non-empty")

        # ===== 템플릿 로드 (edge) =====
        self.templates: List[Tuple[str, np.ndarray]] = []
        for p in template_paths:
            bgr = cv2.imread(p, cv2.IMREAD_COLOR)
            if bgr is None:
                raise FileNotFoundError(p)
            g = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
            g = cv2.GaussianBlur(g, (3, 3), 0)
            edge = cv2.Canny(g, 60, 160)
            self.templates.append((p, edge))

        if init_xy is None:
            init_xy = (frame_w // 2, int(frame_h * 0.78))

        self.last_x, self.last_y = int(init_xy[0]), int(init_xy[1])
        self.smooth_x, self.smooth_y = float(self.last_x), float(self.last_y)
        self.miss_count = 0

        # ===== 디버그 =====
        self.last_match_box = None
        self.last_match_template = None
        self.last_match_scale = None

        self.dbg_best = None
        self.dbg_second = None
        self.dbg_margin = None
        self.dbg_red = None
        self.dbg_white = None
        self.dbg_reject = None
        self.dbg_candidate_center = None
        self.dbg_confirm = None
        self.dbg_votes = None   # NEW: 합의된 후보 개수

    # -------------------------------------------------

    def _roi_from_last(self, frame: np.ndarray):
        r = int(self.base_r * (1.0 + min(self.miss_count, 10) * 0.35))
        x0 = max(0, self.last_x - r)
        y0 = max(0, self.last_y - r)
        x1 = min(self.w, self.last_x + r)
        y1 = min(self.h, self.last_y + r)
        return frame[y0:y1, x0:x1], x0, y0

    def _clamp_xy(self, x: float, y: float):
        return (
            max(0, min(self.w - 1, int(x))),
            max(0, min(self.h - 1, int(y))),
        )

    def _soft_follow(self, cx: int, cy: int):
        a = self.soft_alpha
        self.smooth_x = (1 - a) * self.smooth_x + a * cx
        self.smooth_y = (1 - a) * self.smooth_y + a * cy

    # -------------------------------------------------

    def _estimate_red_white_ratio(self, patch: np.ndarray):
        hsv = cv2.cvtColor(patch, cv2.COLOR_BGR2HSV)

        r1 = cv2.inRange(hsv, (0, 80, 70), (10, 255, 255))
        r2 = cv2.inRange(hsv, (170, 80, 70), (180, 255, 255))
        red = r1 | r2

        white = cv2.inRange(hsv, (0, 0, 180), (180, 60, 255))

        total = patch.shape[0] * patch.shape[1] + 1e-9
        return (
            float(np.count_nonzero(red) / total),
            float(np.count_nonzero(white) / total),
        )

    # -------------------------------------------------

    def _cluster_vote(self, cand_list: List[Tuple[float, int, int, int, int, str, float]]):
        """
        cand_list item:
          (score, cx, cy, tx, ty, tw, th, tmpl_path, scale)
        여기서는 최소 변경을 위해 (score,cx,cy,tx,ty,tw,th,tmpl,scale) 형태로 받는다.
        return:
          best_cluster (votes, mean_score, cx, cy, tx, ty, tw, th, tmpl_path, scale, best_score, second_score)
        """
        if not cand_list:
            return None

        r2 = float(self.vote_radius * self.vote_radius)

        best_votes = 0
        best_sum_score = -1e9
        best_center = None
        best_ref = None  # 대표 박스/템플릿 정보
        best_scores_sorted = None

        for i, it in enumerate(cand_list):
            score_i, cx_i, cy_i, tx_i, ty_i, tw_i, th_i, tmpl_i, sc_i = it

            votes = 0
            sum_score = 0.0
            sum_x = 0.0
            sum_y = 0.0
            scores = []

            for (score_j, cx_j, cy_j, tx_j, ty_j, tw_j, th_j, tmpl_j, sc_j) in cand_list:
                dx = cx_j - cx_i
                dy = cy_j - cy_i
                if (dx * dx + dy * dy) <= r2:
                    votes += 1
                    sum_score += float(score_j)
                    sum_x += float(cx_j)
                    sum_y += float(cy_j)
                    scores.append(float(score_j))

            if votes <= 0:
                continue

            # tie-break: votes 우선, 그 다음 sum_score
            if (votes > best_votes) or (votes == best_votes and sum_score > best_sum_score):
                best_votes = votes
                best_sum_score = sum_score
                best_center = (int(round(sum_x / votes)), int(round(sum_y / votes)))
                best_ref = (tx_i, ty_i, tw_i, th_i, tmpl_i, sc_i)
                scores.sort(reverse=True)
                best_scores_sorted = scores

        if best_center is None:
            return None

        # best/second는 cluster 내 score 기준으로 잡음(대략적인 margin 계산용)
        best_score = best_scores_sorted[0] if best_scores_sorted else -1.0
        second_score = best_scores_sorted[1] if (best_scores_sorted and len(best_scores_sorted) >= 2) else -1.0

        return {
            "votes": best_votes,
            "cx": best_center[0],
            "cy": best_center[1],
            "ref": best_ref,   # (tx,ty,tw,th,tmpl,scale)
            "best": float(best_score),
            "second": float(second_score),
        }

    def _best_and_second_in_roi(self, roi_bgr: np.ndarray):
        """
        기존 함수 시그니처 유지.
        다만 내부 구현은:
        - 템플릿/스케일별 후보들을 cand_list로 모은 뒤
        - cluster vote로 최종 후보를 고름.
        """
        gray = cv2.cvtColor(roi_bgr, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (3, 3), 0)
        edge = cv2.Canny(gray, 60, 160)

        cand_list = []

        for path, tmpl0 in self.templates:
            for s in self.scales:
                tmpl = tmpl0
                if s != 1.0:
                    h, w = tmpl0.shape
                    tmpl = cv2.resize(
                        tmpl0,
                        (max(8, int(w * s)), max(8, int(h * s))),
                        interpolation=cv2.INTER_AREA,
                    )

                th, tw = tmpl.shape
                rh, rw = edge.shape
                if rh < th or rw < tw:
                    continue

                res = cv2.matchTemplate(edge, tmpl, self.method)
                _, maxv, _, maxloc = cv2.minMaxLoc(res)
                score = float(maxv)

                # 너무 약한 후보는 투표에서 제외(노이즈 제거)
                if score < self.vote_min_score:
                    continue

                tx, ty = int(maxloc[0]), int(maxloc[1])
                cx = tx + tw // 2
                cy = ty + th // 2
                cand_list.append((score, cx, cy, tx, ty, tw, th, path, float(s)))

        if not cand_list:
            return None

        voted = self._cluster_vote(cand_list)
        if voted is None or voted["votes"] < self.vote_min:
            # 합의 실패: 그래도 "가장 높은 score 하나"는 리턴해줘서 soft_follow는 가능하게 함
            cand_list.sort(key=lambda x: x[0], reverse=True)
            score, cx, cy, tx, ty, tw, th, path, sc = cand_list[0]
            # second score는 전체 후보 중 2등으로
            second = cand_list[1][0] if len(cand_list) >= 2 else -1.0
            return float(score), float(second), (tx, ty), (tw, th), path, float(sc), 1  # votes=1

        # 합의 성공: cluster 대표 ref + cluster best/second 사용
        tx, ty, tw, th, path, sc = voted["ref"]
        best = voted["best"]
        second = voted["second"]
        return float(best), float(second), (int(tx), int(ty)), (int(tw), int(th)), path, float(sc), int(voted["votes"])

    # -------------------------------------------------

    def update(self, frame_bgr: np.ndarray) -> TrackResult:
        # reset debug
        self.dbg_reject = None
        self.dbg_red = None
        self.dbg_white = None
        self.dbg_candidate_center = None
        self.dbg_confirm = None
        self.dbg_votes = None

        roi, ox, oy = self._roi_from_last(frame_bgr)

        m = self._best_and_second_in_roi(roi)
        if m is None:
            self.miss_count += 1
            cx, cy = self._clamp_xy(self.smooth_x, self.smooth_y)
            self.dbg_reject = "no_match"
            return TrackResult(cx, cy, -1.0, False, "tmpl")

        # (votes 추가)
        best, second, (tx, ty), (tw, th), tmpl_path, sc, votes = m
        margin = best - second

        self.dbg_best = best
        self.dbg_second = second
        self.dbg_margin = margin
        self.dbg_votes = int(votes)

        # 후보 중심
        cand_x, cand_y = self._clamp_xy(
            ox + tx + tw // 2,
            oy + ty + th // 2,
        )
        self.dbg_candidate_center = (cand_x, cand_y)

        # jump 허용
        dx = cand_x - int(self.smooth_x)
        dy = cand_y - int(self.smooth_y)
        dist = (dx * dx + dy * dy) ** 0.5
        dynamic_jump = self.max_jump * (1.0 + 0.6 * min(self.miss_count, 10))
        jump_ok = dist <= dynamic_jump

        # ===== score가 너무 낮을 때만 진짜 reject =====
        if best < self.soft_update_score:
            self.miss_count += 1
            self.dbg_reject = "score"
            cx, cy = self._clamp_xy(self.smooth_x, self.smooth_y)
            return TrackResult(cx, cy, best, False, "tmpl")

        # ✅ 핵심: votes가 충분할 때만 soft_follow 허용 (votes=1 오탐 드리프트 방지)
        if jump_ok and (votes >= self.vote_min):
            self._soft_follow(cand_x, cand_y)

        # ===== vote 합의가 약하면(=1표) 여기서 컷해서 오탐 점프 줄이기 =====
        if votes < self.vote_min:
            self.miss_count += 1
            self.dbg_reject = "vote"
            cx, cy = self._clamp_xy(self.smooth_x, self.smooth_y)
            return TrackResult(cx, cy, best, False, "tmpl")

        # ===== margin 컷 (요정 방어 핵심) =====
        if margin < self.min_margin:
            self.miss_count += 1
            self.dbg_reject = "margin"
            cx, cy = self._clamp_xy(self.smooth_x, self.smooth_y)
            return TrackResult(cx, cy, best, False, "tmpl")

        # ===== color 분석 =====
        patch = roi[ty:ty + th, tx:tx + tw]
        if patch.size > 0:
            rr, wr = self._estimate_red_white_ratio(patch)
            self.dbg_red = rr
            self.dbg_white = wr
            color_ok = (rr >= self.red_min_ratio) and (wr >= self.white_min_ratio)
        else:
            color_ok = False

        self.dbg_confirm = bool(color_ok or (best >= self.strong_score and jump_ok))

        # ===== accept =====
        self.miss_count = 0
        self.last_x, self.last_y = cand_x, cand_y

        a = self.ema_alpha
        self.smooth_x = (1 - a) * self.smooth_x + a * cand_x
        self.smooth_y = (1 - a) * self.smooth_y + a * cand_y

        cx, cy = self._clamp_xy(self.smooth_x, self.smooth_y)
        return TrackResult(cx, cy, best, True, "tmpl")
