# env/debug_viz.py
import cv2
import numpy as np


class DebugViz:
    def __init__(self):
        # ===== On/Off =====
        self.show_tracker_debug = True
        self.show_roi_window = True     # TRACK_ROI 창 켜기/끄기
        self.tracker_show_every = 1
        self._tracker_dbg_i = 0

        # ===== 창 배치 설정 =====
        self.FULL_POS = (50, 50)
        self.ROI_POS = (1600, 80)
        self.ROI_SCALE = 1.1

        # ===== 텍스트 설정 =====
        self.font = cv2.FONT_HERSHEY_SIMPLEX
        self.font_scale = 0.6
        self.thickness = 2
        self.line_gap = 6
        self.text_color = (255, 255, 255)
        self.text_shadow = (0, 0, 0)

    # ----------------------------
    # Drawing helpers
    # ----------------------------
    def _draw_cross(self, img, x, y, size=10, thickness=2, color=(0, 255, 0)):
        x, y = int(x), int(y)
        cv2.line(img, (x - size, y), (x + size, y), color, thickness)
        cv2.line(img, (x, y - size), (x, y + size), color, thickness)

    def _put_lines(self, img, lines, x=10, y=10):
        """멀티라인 텍스트 (그림자 포함)"""
        cy = int(y)
        for line in lines:
            if line is None:
                continue
            line = str(line)
            (tw, th), _ = cv2.getTextSize(line, self.font, self.font_scale, self.thickness)
            # shadow
            cv2.putText(img, line, (int(x) + 1, cy + th + 1), self.font,
                        self.font_scale, self.text_shadow, self.thickness + 1, cv2.LINE_AA)
            # text
            cv2.putText(img, line, (int(x), cy + th), self.font,
                        self.font_scale, self.text_color, self.thickness, cv2.LINE_AA)
            cy += th + self.line_gap

    def _safe_roi_from_tracker(self, tracker, img_bgr):
        """
        tracker._roi_from_last(img_bgr)가 있으면 그것을 사용.
        없으면 전체 이미지를 ROI로 사용.
        return: (roi, ox, oy)
        """
        fn = getattr(tracker, "_roi_from_last", None)
        if callable(fn):
            try:
                roi, ox, oy = fn(img_bgr)
                if roi is not None and roi.size > 0:
                    return roi, int(ox), int(oy)
            except Exception:
                pass
        # fallback: whole frame
        return img_bgr, 0, 0

    def _unpack_last_match_box(self, tracker):
        """
        tracker.last_match_box가
        - (x,y,w,h) 4개
        - (meta1,meta2,x,y,w,h) 6개
        - 기타 형태
        를 모두 처리해서 (tx,ty,tw,th, meta1, meta2)를 반환.
        없으면 None.
        """
        lb = getattr(tracker, "last_match_box", None)
        if lb is None:
            return None

        if isinstance(lb, (tuple, list)):
            if len(lb) == 4:
                tx, ty, tw, th = lb
                return int(tx), int(ty), int(tw), int(th), None, None
            if len(lb) == 6:
                meta1, meta2, tx, ty, tw, th = lb
                return int(tx), int(ty), int(tw), int(th), meta1, meta2

        # 알 수 없는 포맷이면 포기
        return None

    def _box_to_roi_coords(self, tx, ty, tw, th, ox, oy, rw, rh):
        """
        tx,ty가 ROI 기준인지(0~rw/rh) 또는 화면 절대좌표인지(ox/oy 포함) 모호할 수 있음.
        휴리스틱으로 ROI 좌표로 맞춰준다.
        """
        # 이미 ROI 내부 좌표처럼 보이면 그대로
        if 0 <= tx < rw and 0 <= ty < rh:
            return tx, ty, tw, th

        # 절대 좌표일 가능성: ROI 원점을 빼본다
        rx = tx - ox
        ry = ty - oy
        return rx, ry, tw, th

    def _edge_px_string(self, tracker):
        """
        DetTrackTracker 쪽에서 edge 거리(px)를 제공하면 표시.
        없으면 '-' 처리.
        """
        for name in ("dbg_edge_px", "edge_px", "edge_dist_px"):
            v = getattr(tracker, name, None)
            if v is not None:
                try:
                    return f"{float(v):.1f}px"
                except Exception:
                    return str(v)
        return "-"

    # ----------------------------
    # Main
    # ----------------------------
    def show_tracker(self, img_bgr, tracker, tr, crop_size):
        if not self.show_tracker_debug:
            return

        self._tracker_dbg_i += 1
        if (self._tracker_dbg_i % max(1, self.tracker_show_every)) != 0:
            return

        # ROI 정보(있으면) 가져오기
        roi, ox, oy = self._safe_roi_from_tracker(tracker, img_bgr)
        rh, rw = roi.shape[:2]

        # TRACK_FULL
        full = img_bgr.copy()

        # ROI 박스(파랑) - 전체 프레임 ROI면 그려도 의미 없으니 조건부
        if not (ox == 0 and oy == 0 and rw == full.shape[1] and rh == full.shape[0]):
            cv2.rectangle(full, (ox, oy), (ox + rw, oy + rh), (255, 0, 0), 2)

        # 중심: cand가 있으면 cand 우선, 없으면 tr.x,tr.y
        cand = getattr(tracker, "dbg_candidate_center", None)

        # tr 호환 (새 TrackResult/기존 TrackResult 모두)
        tr_x = getattr(tr, "x", None)
        tr_y = getattr(tr, "y", None)
        tr_conf = float(getattr(tr, "conf", 0.0) or 0.0)
        tr_method = getattr(tr, "method", "trk")
        miss = getattr(tracker, "miss_count", -1)

        if cand is not None:
            try:
                cx, cy = int(cand[0]), int(cand[1])
            except Exception:
                cx, cy = (int(tr_x) if tr_x is not None else 0), (int(tr_y) if tr_y is not None else 0)
        else:
            cx, cy = (int(tr_x) if tr_x is not None else 0), (int(tr_y) if tr_y is not None else 0)

        # 중심 십자(초록)
        self._draw_cross(full, cx, cy, size=10, thickness=2, color=(0, 255, 0))

        # crop 박스(노랑)
        try:
            half = int(crop_size) // 2
            cv2.rectangle(
                full,
                (int(cx - half), int(cy - half)),
                (int(cx + half), int(cy + half)),
                (0, 255, 255),
                2
            )
        except Exception:
            pass

        # 후보 표시(청록)
        if cand is not None:
            try:
                self._draw_cross(full, cand[0], cand[1], size=8, thickness=2, color=(255, 255, 0))
            except Exception:
                pass

        # 텍스트 디버그
        best = getattr(tracker, "dbg_best", None)
        second = getattr(tracker, "dbg_second", None)
        margin = getattr(tracker, "dbg_margin", None)
        red = getattr(tracker, "dbg_red", None)
        white = getattr(tracker, "dbg_white", None)
        rej = getattr(tracker, "dbg_reject", None)
        votes = getattr(tracker, "dbg_votes", None)

        best_s = "-" if best is None else f"{float(best):.3f}"
        second_s = "-" if second is None else f"{float(second):.3f}"
        margin_s = "-" if margin is None else f"{float(margin):.3f}"
        red_s = "-" if red is None else f"{float(red):.3f}"
        white_s = "-" if white is None else f"{float(white):.3f}"
        rej_s = "-" if rej is None else str(rej)
        votes_s = "-" if votes is None else str(int(votes))

        edge_s = self._edge_px_string(tracker)

        lines = [
            f"[{tr_method}] conf={tr_conf:.3f} miss={miss} votes={votes_s} reject={rej_s} edge={edge_s}",
            f"center: cx={cx} cy={cy}  cand={cand}",
            f"score: best={best_s} second={second_s} margin={margin_s}",
            f"color: red={red_s} white={white_s}  crop={crop_size}",
        ]

        self._put_lines(full, lines, x=10, y=10)
        cv2.imshow("TRACK_FULL", full)
        cv2.moveWindow("TRACK_FULL", *self.FULL_POS)

        # TRACK_ROI (옵션)
        if self.show_roi_window:
            roi_show = roi.copy()

            # last_match_box 그리기(가능하면)
            unpacked = self._unpack_last_match_box(tracker)
            if unpacked is not None:
                tx, ty, tw, th, meta1, meta2 = unpacked
                rx, ry, rw_box, rh_box = self._box_to_roi_coords(tx, ty, tw, th, ox, oy, rw, rh)

                # ROI 영역 밖이면 그리기 생략
                if rw_box > 0 and rh_box > 0:
                    # 박스 clamp
                    x0 = max(0, min(rw - 1, int(rx)))
                    y0 = max(0, min(rh - 1, int(ry)))
                    x1 = max(0, min(rw - 1, int(rx + rw_box)))
                    y1 = max(0, min(rh - 1, int(ry + rh_box)))
                    if x1 > x0 and y1 > y0:
                        cv2.rectangle(roi_show, (x0, y0), (x1, y1), (0, 255, 0), 2)

            # ROI 확대
            scale = float(self.ROI_SCALE)
            roi_show = cv2.resize(
                roi_show,
                (max(1, int(rw * scale)), max(1, int(rh * scale))),
                interpolation=cv2.INTER_NEAREST
            )

            cv2.imshow("TRACK_ROI", roi_show)
            cv2.moveWindow("TRACK_ROI", *self.ROI_POS)

        cv2.waitKey(1)
