# env/debug_viz.py
import cv2
import numpy as np

class DebugViz:
    def __init__(self):
        self.show_tracker_debug = True
        self.tracker_show_every = 1
        self._tracker_dbg_i = 0

        # ===== 창 배치 설정 =====
        self.FULL_POS = (50, 50)
        self.ROI_POS = (1600, 80)
        self.ROI_SCALE = 1.1

        # ===== 텍스트 설정 =====
        self.FONT = cv2.FONT_HERSHEY_SIMPLEX
        self.FONT_SCALE = 0.55
        self.FONT_THICK = 2
        self.TEXT_COLOR = (30, 255, 30)
        self.BG_COLOR = (0, 0, 0)

    def _draw_cross(self, img, x, y, size=6, thickness=1, color=(0, 255, 0)):
        x = int(x); y = int(y)
        cv2.line(img, (x - size, y), (x + size, y), color, thickness)
        cv2.line(img, (x, y - size), (x, y + size), color, thickness)

    def _put_lines(self, img, lines, x=10, y=10, line_gap=6):
        """
        좌상단에 여러 줄 텍스트를 '배경 박스'와 함께 그려서 항상 잘 보이게.
        """
        if not lines:
            return

        sizes = [cv2.getTextSize(t, self.FONT, self.FONT_SCALE, self.FONT_THICK)[0] for t in lines]
        w = max(s[0] for s in sizes) + 14
        h = sum(s[1] for s in sizes) + line_gap * (len(lines) - 1) + 14

        cv2.rectangle(img, (x, y), (x + w, y + h), self.BG_COLOR, thickness=-1)

        cy = y + 10 + sizes[0][1]
        for i, t in enumerate(lines):
            cv2.putText(
                img, t, (x + 7, cy),
                self.FONT, self.FONT_SCALE,
                self.TEXT_COLOR, self.FONT_THICK,
                cv2.LINE_AA
            )
            if i + 1 < len(lines):
                cy += sizes[i + 1][1] + line_gap

    def show_tracker(self, img_bgr, tracker, tr, crop_size):
        if not self.show_tracker_debug:
            return

        self._tracker_dbg_i += 1
        if (self._tracker_dbg_i % max(1, self.tracker_show_every)) != 0:
            return

        roi, ox, oy = tracker._roi_from_last(img_bgr)
        rh, rw = roi.shape[:2]

        # =========================
        # TRACK_FULL
        # =========================
        full = img_bgr.copy()

        # ROI 박스(파랑)
        cv2.rectangle(full, (ox, oy), (ox + rw, oy + rh), (255, 0, 0), 2)

        # 중심 = cand 우선
        cand = getattr(tracker, "dbg_candidate_center", None)
        if cand is not None:
            cx, cy = int(cand[0]), int(cand[1])
        else:
            cx, cy = int(tr.x), int(tr.y)

        # 중심 십자(초록)
        self._draw_cross(full, cx, cy, size=10, thickness=2, color=(0, 255, 0))

        # crop 박스(노랑)
        half = int(crop_size) // 2
        cv2.rectangle(
            full,
            (int(cx - half), int(cy - half)),
            (int(cx + half), int(cy + half)),
            (0, 255, 255),
            2
        )

        # 후보 위치 별도 표시(청록) - cand가 있으면 동일 위치지만, 시각적으로 구분용
        if cand is not None:
            self._draw_cross(full, cand[0], cand[1], size=8, thickness=2, color=(255, 255, 0))

        # =========================
        # 텍스트 (votes 포함)
        # =========================
        method = getattr(tr, "method", "trk")
        miss = getattr(tracker, "miss_count", -1)

        best   = getattr(tracker, "dbg_best", None)
        second = getattr(tracker, "dbg_second", None)
        margin = getattr(tracker, "dbg_margin", None)
        red    = getattr(tracker, "dbg_red", None)
        white  = getattr(tracker, "dbg_white", None)
        rej    = getattr(tracker, "dbg_reject", None)
        votes  = getattr(tracker, "dbg_votes", None)

        # 보기 좋게 포맷
        best_s   = "-" if best   is None else f"{float(best):.3f}"
        second_s = "-" if second is None else f"{float(second):.3f}"
        margin_s = "-" if margin is None else f"{float(margin):.3f}"
        red_s    = "-" if red    is None else f"{float(red):.3f}"
        white_s  = "-" if white  is None else f"{float(white):.3f}"
        rej_s    = "-" if rej    is None else str(rej)
        votes_s  = "-" if votes  is None else str(int(votes))

        lines = [
            f"[{method}] conf={tr.conf:.3f} miss={miss}  votes={votes_s}  reject={rej_s}",
            f"center: cx={cx} cy={cy}  cand={cand}",
            f"score: best={best_s} second={second_s} margin={margin_s}",
            f"color: red={red_s} white={white_s}  crop={crop_size}",
        ]

        self._put_lines(full, lines, x=10, y=10)

        cv2.imshow("TRACK_FULL", full)

        # =========================
        # TRACK_ROI
        # =========================
        roi_show = roi.copy()

        if hasattr(tracker, "last_match_box") and tracker.last_match_box is not None:
            (_, _, tx, ty, tw, th) = tracker.last_match_box
            cv2.rectangle(
                roi_show,
                (int(tx), int(ty)),
                (int(tx + tw), int(ty + th)),
                (0, 255, 255),
                2
            )

        scale = float(self.ROI_SCALE)
        roi_show = cv2.resize(
            roi_show,
            (max(1, int(rw * scale)), max(1, int(rh * scale))),
            interpolation=cv2.INTER_NEAREST
        )

        cv2.imshow("TRACK_ROI", roi_show)

        cv2.moveWindow("TRACK_FULL", *self.FULL_POS)
        cv2.moveWindow("TRACK_ROI", *self.ROI_POS)

        cv2.waitKey(1)
