# env/det_track_tracker.py
from __future__ import annotations
from dataclasses import dataclass
import cv2
import numpy as np

from env.template_tracker import MultiTemplateTracker


@dataclass
class TrackResult:
    x: int
    y: int
    conf: float
    found: bool
    method: str  # "track" or "detect"


def _create_cv_tracker(prefer: str = "CSRT"):
    """
    OpenCV tracker factory (버전 호환)
    prefer: "CSRT" (정확) or "MOSSE" (빠름)
    """
    name = prefer.upper()

    # OpenCV 4.5+에서 legacy로 들어간 경우가 많음
    legacy = getattr(cv2, "legacy", None)

    def _try(fn):
        try:
            return fn()
        except Exception:
            return None

    if name == "CSRT":
        if legacy is not None and hasattr(legacy, "TrackerCSRT_create"):
            t = _try(legacy.TrackerCSRT_create)
            if t is not None:
                return t
        if hasattr(cv2, "TrackerCSRT_create"):
            t = _try(cv2.TrackerCSRT_create)
            if t is not None:
                return t

    if name == "MOSSE":
        if legacy is not None and hasattr(legacy, "TrackerMOSSE_create"):
            t = _try(legacy.TrackerMOSSE_create)
            if t is not None:
                return t
        if hasattr(cv2, "TrackerMOSSE_create"):
            t = _try(cv2.TrackerMOSSE_create)
            if t is not None:
                return t

    # fallback: KCF
    if legacy is not None and hasattr(legacy, "TrackerKCF_create"):
        t = _try(legacy.TrackerKCF_create)
        if t is not None:
            return t
    if hasattr(cv2, "TrackerKCF_create"):
        t = _try(cv2.TrackerKCF_create)
        if t is not None:
            return t

    raise RuntimeError("No supported OpenCV tracker found (CSRT/MOSSE/KCF).")


class DetTrackTracker:
    """
    Detector(템플릿) + Tracker(OpenCV) 하이브리드

    - 평소: cv tracker로 연속 추적
    - 실패/주기적: template detector로 재획득/재동기화

    디버그 변수는 기존 DebugViz와 최대한 맞춰서 제공:
      - miss_count
      - dbg_candidate_center, dbg_votes, dbg_best/second/margin, dbg_reject 등은 detector에서 가져옴
    """

    def __init__(
        self,
        frame_w: int,
        frame_h: int,
        template_paths: list[str],
        init_xy: tuple[int, int] | None = None,

        # tracker 관련
        tracker_prefer: str = "CSRT",
        init_box: int = 56,           # detector 좌표 기준으로 생성할 bbox 크기(px)
        track_fail_to_detect: int = 2,  # tracker가 몇 번 연속 실패하면 detect 모드로 강제 전환
        redetect_every: int = 15,      # N프레임마다 detector로 재동기화(드리프트 방지)

        # detector 파라미터는 MultiTemplateTracker 그대로 넘김
        **detector_kwargs,
    ):
        self.w = frame_w
        self.h = frame_h

        self.init_box = int(init_box)
        self.track_fail_to_detect = int(track_fail_to_detect)
        self.redetect_every = int(redetect_every)

        self.detector = MultiTemplateTracker(
            frame_w=frame_w,
            frame_h=frame_h,
            template_paths=template_paths,
            init_xy=init_xy,
            **detector_kwargs,
        )

        # 상태
        if init_xy is None:
            init_xy = (frame_w // 2, int(frame_h * 0.78))
        self.last_x, self.last_y = int(init_xy[0]), int(init_xy[1])

        self._tracker_prefer = str(tracker_prefer)
        self._cv_tracker = None
        self._track_ok = False
        self._track_fail_streak = 0
        self._frame_i = 0

        # Debug passthrough
        self.miss_count = 0
        self.last_match_box = None

        self.dbg_best = None
        self.dbg_second = None
        self.dbg_margin = None
        self.dbg_red = None
        self.dbg_white = None
        self.dbg_reject = None
        self.dbg_candidate_center = None
        self.dbg_confirm = None
        self.dbg_votes = None

    # -----------------------------

    def _clamp_box(self, x, y, w, h):
        x = int(max(0, min(self.w - 1, x)))
        y = int(max(0, min(self.h - 1, y)))
        w = int(max(8, min(self.w - x, w)))
        h = int(max(8, min(self.h - y, h)))
        return x, y, w, h

    def _box_from_center(self, cx: int, cy: int, size: int):
        half = size // 2
        x = cx - half
        y = cy - half
        return self._clamp_box(x, y, size, size)

    def _init_tracker(self, frame_bgr: np.ndarray, cx: int, cy: int):
        self._cv_tracker = _create_cv_tracker(self._tracker_prefer)
        x, y, w, h = self._box_from_center(cx, cy, self.init_box)
        ok = bool(self._cv_tracker.init(frame_bgr, (x, y, w, h)))
        self._track_ok = ok
        self._track_fail_streak = 0
        if ok:
            self.last_match_box = (x, y, w, h)

    def _update_tracker(self, frame_bgr: np.ndarray):
        if self._cv_tracker is None:
            return False, None
        ok, box = self._cv_tracker.update(frame_bgr)
        if not ok:
            return False, None
        x, y, w, h = box
        x, y, w, h = self._clamp_box(int(x), int(y), int(w), int(h))
        cx = x + w // 2
        cy = y + h // 2
        self.last_match_box = (x, y, w, h)
        return True, (cx, cy)

    # -----------------------------

    def _copy_detector_debug(self):
        # detector의 디버그 정보 그대로 노출
        self.dbg_best = getattr(self.detector, "dbg_best", None)
        self.dbg_second = getattr(self.detector, "dbg_second", None)
        self.dbg_margin = getattr(self.detector, "dbg_margin", None)
        self.dbg_red = getattr(self.detector, "dbg_red", None)
        self.dbg_white = getattr(self.detector, "dbg_white", None)
        self.dbg_reject = getattr(self.detector, "dbg_reject", None)
        self.dbg_candidate_center = getattr(self.detector, "dbg_candidate_center", None)
        self.dbg_confirm = getattr(self.detector, "dbg_confirm", None)
        self.dbg_votes = getattr(self.detector, "dbg_votes", None)

        # miss_count도 detector 기반으로 반영
        self.miss_count = getattr(self.detector, "miss_count", 0)

        # detector가 마지막에 매치한 박스가 있으면(있을 수도/없을 수도)
        lb = getattr(self.detector, "last_match_box", None)
        if lb is not None:
            self.last_match_box = lb

    # -----------------------------

    def _roi_from_last(self, img_bgr):
        """
        DebugViz 호환용.
        기존 DebugViz가 tracker._roi_from_last(img_bgr)를 호출하므로,
        내부 detector(MultiTemplateTracker)의 ROI 함수를 그대로 위임한다.
        """
        return self.detector._roi_from_last(img_bgr)


    def update(self, frame_bgr: np.ndarray) -> TrackResult:
        self._frame_i += 1

        # 1) 기본은 tracker로 시도
        used_detect = False

        # 주기적 재탐지(드리프트 방지): N프레임마다 detector를 한번 돌려서 재동기화
        force_redetect = (self.redetect_every > 0) and (self._frame_i % self.redetect_every == 0)

        if self._track_ok and not force_redetect:
            ok, center = self._update_tracker(frame_bgr)
            if ok and center is not None:
                cx, cy = center
                self.last_x, self.last_y = int(cx), int(cy)
                self._track_fail_streak = 0
                self.detector.last_x, self.detector.last_y = self.last_x, self.last_y  # detector ROI도 따라오게
                self.detector.smooth_x, self.detector.smooth_y = float(self.last_x), float(self.last_y)

                # tracker 모드에서는 detector debug는 "마지막 값" 유지 (원하면 None으로 지워도 됨)
                return TrackResult(self.last_x, self.last_y, 1.0, True, "track")

            # tracker 실패
            self._track_fail_streak += 1
            if self._track_fail_streak < self.track_fail_to_detect:
                # 아직은 “잠깐 실패”로 보고 마지막 위치 유지
                return TrackResult(self.last_x, self.last_y, 0.0, False, "track")

        # 2) detector로 재획득
        used_detect = True
        det = self.detector.update(frame_bgr)
        self._copy_detector_debug()

        # detector 결과로 center 확정 (obs_builder가 cand를 쓰는 구조라서 cand도 제공됨)
        cx, cy = int(det.x), int(det.y)

        # "합의(votes)"가 충분하면 그 좌표로 tracker 재초기화
        votes = int(getattr(self.detector, "dbg_votes", 0) or 0)
        cand = getattr(self.detector, "dbg_candidate_center", None)
        if cand is not None and votes >= getattr(self.detector, "vote_min", 2):
            cx, cy = int(cand[0]), int(cand[1])

        if det.found:
            self.last_x, self.last_y = cx, cy
            self._init_tracker(frame_bgr, self.last_x, self.last_y)
            return TrackResult(self.last_x, self.last_y, float(det.conf), True, "detect")

        # detector도 실패하면 마지막 위치 유지(미스 증가)
        return TrackResult(self.last_x, self.last_y, float(det.conf), False, "detect")
