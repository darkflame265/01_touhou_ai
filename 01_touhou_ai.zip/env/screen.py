import win32gui
import mss
import cv2
import numpy as np


def find_touhou_window():
    target_hwnd = None

    def enum_handler(hwnd, _):
        nonlocal target_hwnd
        if win32gui.IsWindowVisible(hwnd):
            title = win32gui.GetWindowText(hwnd)
            if "동방홍마향" in title:
                target_hwnd = hwnd

    win32gui.EnumWindows(enum_handler, None)
    return target_hwnd


class Screen:
    PLAYFIELD_RIGHT_RATIO = 0.70

    PLAYFIELD_TOP_CROP = 0.00
    PLAYFIELD_BOTTOM_CROP = 1.00
    PLAYFIELD_LEFT_CROP = 0.00
    PLAYFIELD_RIGHT_CROP = 1.00

    UI_EDGE_RATIO_THR = 0.040
    UI_STD_MIN = 15.0
    UI_STD_MAX = 80.0
    UI_MEAN_MIN = 20.0
    UI_MEAN_MAX = 200.0

    def __init__(self, mode="low"):
        self.mode = mode
        self.sct = mss.mss()
        self.hwnd = find_touhou_window()

        if not self.hwnd:
            raise Exception("동방홍마향 창을 찾을 수 없음")

        title = win32gui.GetWindowText(self.hwnd)
        rect = win32gui.GetWindowRect(self.hwnd)

        print("[DEBUG] 잡은 창 제목:", title)
        print("[DEBUG] 창 좌표 (left, top, right, bottom):", rect)

    def capture(self):
        win32gui.ShowWindow(self.hwnd, 9)  # SW_RESTORE
        win32gui.SetForegroundWindow(self.hwnd)

        left, top, right, bottom = win32gui.GetWindowRect(self.hwnd)

        monitor = {
            "left": left,
            "top": top,
            "width": right - left,
            "height": bottom - top
        }

        img = np.array(self.sct.grab(monitor))
        img = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
        return img

    def get_playfield_gray(self, img_bgr):
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape

        x2 = int(w * self.PLAYFIELD_RIGHT_RATIO)
        play = gray[:, :x2]

        ph, pw = play.shape
        x1 = int(pw * self.PLAYFIELD_LEFT_CROP)
        x2 = int(pw * self.PLAYFIELD_RIGHT_CROP)
        y1 = int(ph * self.PLAYFIELD_TOP_CROP)
        y2 = int(ph * self.PLAYFIELD_BOTTOM_CROP)

        play = play[y1:y2, x1:x2]
        return play

    def preprocess(self, img_bgr):
        play = self.get_playfield_gray(img_bgr)

        if self.mode == "low":
            resized = cv2.resize(play, (84, 84), interpolation=cv2.INTER_AREA)
        else:
            resized = cv2.resize(play, (160, 120), interpolation=cv2.INTER_AREA)

        return (resized.astype(np.float32) / 255.0)

    def ui_panel_present(self, img_bgr) -> bool:
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape
        x1 = int(w * self.PLAYFIELD_RIGHT_RATIO)
        panel = gray[:, x1:]

        if panel.size == 0:
            return False

        mean = float(panel.mean())
        std = float(panel.std())
        edges = cv2.Canny(panel, 80, 160)
        edge_ratio = float((edges > 0).mean())

        ok = (
            (edge_ratio >= self.UI_EDGE_RATIO_THR) and
            (self.UI_STD_MIN <= std <= self.UI_STD_MAX) and
            (self.UI_MEAN_MIN <= mean <= self.UI_MEAN_MAX)
        )
        return bool(ok)

    def playfield_motion_score(self, prev_play_gray, curr_play_gray):
        diff = cv2.absdiff(prev_play_gray, curr_play_gray)
        return float(diff.mean()) / 255.0

    def danger_from_playfield(self, play_gray, return_parts=False):
        h, w = play_gray.shape

        y1 = int(h * 0.60)
        y2 = int(h * 0.98)
        x1 = int(w * 0.20)
        x2 = int(w * 0.80)

        roi = play_gray[y1:y2, x1:x2]
        if roi.size == 0:
            if return_parts:
                return 0.0, 0.0, 0.0, 0.0
            return 0.0

        edges = cv2.Canny(roi, 50, 120)
        edge_ratio = float((edges > 0).mean())
        bright_ratio = float((roi > 160).mean())
        std_norm = float(roi.std()) / 255.0

        danger = 0.0
        danger += 4.0 * edge_ratio
        danger += 2.0 * bright_ratio
        danger += 1.2 * std_norm
        danger = max(0.0, min(1.0, danger))

        if return_parts:
            return float(danger), float(edge_ratio), float(bright_ratio), float(std_norm)
        return float(danger)

    def detect_death(self, img_bgr):
        """
        ✅ 'UI 잔기 감소'보다 빠르게 잡기 위한 즉시 신호.
        - gameover: 전체 화면이 매우 밝아짐(플래시)
        - hit: 플레이어 근처 ROI에 밝은 플래시가 순간적으로 뜨는 비율

        return: (hit, gameover)
        """
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
        h, w = gray.shape

        full_brightness = gray.mean() / 255.0
        gameover = full_brightness > 0.82

        # 아래쪽 중앙(플레이어 근처로 가정)
        x1 = int(w * 0.35)
        x2 = int(w * 0.65)
        y1 = int(h * 0.60)
        y2 = int(h * 0.95)

        roi = gray[y1:y2, x1:x2]
        bright_ratio = float((roi > 225).mean())
        hit = bright_ratio > 0.020

        return hit, gameover
